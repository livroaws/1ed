package br.livroaws.s3.demo;

import java.io.IOException;

public class TesteS3ListBuckets {

	public static void main(String[] args) throws IOException {
		S3Helper s3 = new S3Helper();

		// Conecta no S3
		s3.connect();

		// Lista todos os buckets
		s3.listBuckets();
		
		
	}
}
