package br.livro.android.cap20.push;

/**
 * @author Ricardo Lecheta
 * 
 */
public interface Constants {

	/**
	 * "Project Number" registrado no console do Google Cloud Platform
	 * 
	 * http://cloud.google.com/console
	 */
//	String PROJECT_NUMBER = "686844393032";
	
//	String PROJECT_NUMBER = "262957121671";
	
	String PROJECT_NUMBER = "941293702043";
}
